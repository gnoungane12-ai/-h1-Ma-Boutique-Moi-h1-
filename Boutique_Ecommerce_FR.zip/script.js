document.querySelectorAll("button").forEach(bouton => {
    bouton.addEventListener("click", () => {
        alert("Produit ajouté au panier 🛒");
    });
});
