# Boutique Colorée

Une petite boutique e-commerce simple et colorée en HTML, CSS et JavaScript.
Ce projet est en français et idéal pour débutants.

## Fichiers inclus :
- index.html → structure du site
- style.css → design coloré et moderne
- script.js → actions interactives
